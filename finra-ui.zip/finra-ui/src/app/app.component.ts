import { Component } from '@angular/core';

@Component({
  selector: 'finra-root',
  templateUrl: "app.component.html"
})
export class AppComponent {
  pageTitle: string = 'Finra Phone Exercise';
}
