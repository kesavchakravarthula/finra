import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from "@angular/forms";
import { RouterModule, Router } from "@angular/router";
import { HttpModule } from "@angular/http";
import { PhoneComponent } from './phone.component';
import { PhoneService } from './phone.service';
import { Phone } from './phone.model';


@NgModule({
  declarations: [PhoneComponent],
  imports: [BrowserModule, FormsModule, HttpModule],
  providers: [PhoneService, Phone],
  exports:[PhoneComponent]
})
export class PhoneModule { }
