import { Component } from "@angular/core";
import { NgForm } from "@angular/forms";
import { Observable } from "rxjs/Observable";
import { Http, Request, RequestMethod, Response } from "@angular/http"
import 'rxjs/add/operator/map'
import "rxjs/add/observable/from";
import { PhoneService } from "./phone.service";
import { Phone } from "./phone.model";

@Component({
    selector: 'phone-component',
    templateUrl: "phone.component.html",
    styleUrls: ["phone.component.css"]
})
export class PhoneComponent {
    phoneNumber: string;
    pageSize: string = "2";
    pageNumber: string;
    errorMessage: string;
    numberOfPages: number[] = [];
    submitted: boolean = false;
    constructor(private _phoneService: PhoneService, private phone: Phone) {}

    submitPhoneNumber(form: NgForm) {
        this.errorMessage = null;
        if (form.valid && (this.phoneNumber.length == 7 || this.phoneNumber.length == 10)) {
            console.log(this.phoneNumber);
            this.getPhoneNums();
            this.submitted = false;
        }
        else
        {
            this.errorMessage = "Please enter valid phone number (length should be 7 or 10)"
        }
    }

    changePageSize(pageSize: string) {
        this.pageSize = pageSize;        
        this.changePage("1");
    }

    changePage(pageNumber: string) {
        this.pageNumber = pageNumber;
        this.getPhoneNums();
    }

    getPhoneNums(): void {
        this._phoneService.getPhoneNums(this.phoneNumber, this.pageSize, this.pageNumber)
            .subscribe(phone => {
                this.phone = phone
                this.numberOfPages = Array(phone.numberOfPages).fill(0).map((x,i)=>i + 1);
            },
            error => this.errorMessage = <any>error);
    }
}