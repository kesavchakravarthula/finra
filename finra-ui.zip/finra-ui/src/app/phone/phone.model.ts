export class Phone {
    public size?: number = 0;
    public numberOfPages?: number = 0;
    public result?: string[];
    public selectedPageNumber?: number = 0;
    public pageNumber = 0;
}