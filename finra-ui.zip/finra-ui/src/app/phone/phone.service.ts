import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';
import { Injectable } from "@angular/core";
import { Phone } from "./phone.model";

@Injectable()
export class PhoneService {

    private _phoneServiceURL = "http://localhost:8080/phones?";
    private pageSize;
    private phoneNumber;
    private pageNumber;

    constructor(private _http: HttpClient) { }

    getPhoneNums(phoneNumber: string, pageSize: string = "4", pageNumber: string = "1"): Observable<Phone> {
        this.pageNumber = pageNumber;
        this.pageSize = pageSize;
        this.phoneNumber = phoneNumber;
        let url = this._phoneServiceURL
            + "pageNumber=" + this.pageNumber
            + "&phoneNumbersPerPage=" + pageSize
            + "&phoneNumber=" + phoneNumber;
        return this._http.get<Phone>(url)
            .do(data => console.log(JSON.stringify(data)))
            .catch(this.handleError);
    }

    private handleError(err: HttpErrorResponse) {
        let errorMessage = '';
        if (err.error instanceof Error) {
            errorMessage = `An error occurred: ${err.error.message}`;
        } else {
            errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
        }
        console.error(errorMessage);
        return Observable.throw(errorMessage);
    }
}