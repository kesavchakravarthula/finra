package com.finra;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Kesav Nallan
 *
 */
public class Phone {

	private int size;
	private double numberOfPages;
	private List<String> result = new ArrayList<String>();
	private int selectedPageNumber;
	
	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public List<String> getResult() {
		return result;
	}

	public void setResult(List<String> result) {
		this.result = result;
	}

	public void setNumberOfPages(double numberOfPages) {
		this.numberOfPages = numberOfPages;
	}

	public double getNumberOfPages() {
		return numberOfPages;
	}

	public int getSelectedPageNumber() {
		return selectedPageNumber;
	}

	public void setSelectedPageNumber(int selectedPageNumber) {
		this.selectedPageNumber = selectedPageNumber;
	}

}
