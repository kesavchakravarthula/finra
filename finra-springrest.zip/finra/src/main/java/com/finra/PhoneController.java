package com.finra;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
/**
 * @author Kesav Nallan
 * 
 * This controller generates phone numbers based on the input
 *
 */
@RestController
public class PhoneController {

	public static final Map<String, List<String>> NumbersAndAlphabets = new HashMap<String, List<String>>();

	static {
		NumbersAndAlphabets.put("0", Arrays.asList("0"));
		NumbersAndAlphabets.put("1", Arrays.asList("1"));
		NumbersAndAlphabets.put("2", Arrays.asList("A", "B", "C"));
		NumbersAndAlphabets.put("3", Arrays.asList("D", "E", "F"));
		NumbersAndAlphabets.put("4", Arrays.asList("G", "H", "I"));
		NumbersAndAlphabets.put("5", Arrays.asList("J", "K", "L"));
		NumbersAndAlphabets.put("6", Arrays.asList("M", "N", "O"));
		NumbersAndAlphabets.put("7", Arrays.asList("P", "Q", "R", "S"));
		NumbersAndAlphabets.put("8", Arrays.asList("T", "U", "V"));
		NumbersAndAlphabets.put("9", Arrays.asList("W", "X", "Y", "Z"));
	}
	
	@GetMapping("/phones")
	public Phone getPhones(
			@RequestParam(value = "phoneNumber") String phoneNumber,
			@RequestParam(value="pageNumber") String pageNumber,
			@RequestParam(value="phoneNumbersPerPage") String phoneNumbersPerPage) {
		List<String> result = new ArrayList<>();
		List<String> filteredNumbers = new ArrayList<>();
		String[] phoneNumberArray = phoneNumber.split("(?!^)");
		Phone phone = new Phone();
		int phonenumsperpage = Integer.parseInt(phoneNumbersPerPage);
		int pagenum = Integer.parseInt(pageNumber);
		int pageIndex = (pagenum - 1) * phonenumsperpage;
		
		for (int i = 0; i < phoneNumber.length(); i++) {
			List<String> value = NumbersAndAlphabets.get(phoneNumberArray[i]);
			for (int j = 0; j < value.size(); j++) {
				String combination = new StringBuilder().append(phoneNumber.substring(0, i)).append(value.get(j)).append(phoneNumber.substring(i + 1)).toString();
				if (!combination.equals(phoneNumber)) {					
					result.add(combination);
				}
			}
		}
		
		if((pageIndex + phonenumsperpage) > result.size()  ) {
			filteredNumbers = result.subList(pageIndex, result.size()); 
		}
		else {
			filteredNumbers= result.subList(pageIndex, (pageIndex + phonenumsperpage));
		}
		
		phone.setSize(result.size());
		phone.setNumberOfPages(Math.ceil(result.size()/ phonenumsperpage) + 1);
		phone.getResult().addAll(filteredNumbers);
		phone.setSelectedPageNumber(Integer.parseInt(pageNumber));
		return phone;
	}

}